Fatoor POS v3.4 (Windows Portable — Electron)

تشغيل محلي (اختياري):
1) تثبيت Node.js LTS
2) npm install
3) npm start

إنشاء EXE محمول:
1) npm install
2) npm run dist
   (ينشئ dist\Fatoor POS Portable.exe)

المدير الافتراضي: admin / admin
